# resume
"# resume"
## 刘园园个人简历

 ### 电话：13022157552
 ### 邮箱：1551176788@qq.com
 ### 学校：河南职业技术学院
 ### 专业：计算机多媒体技术
 ### github: [https://github.com/liuyuan726](https://github.com/liuyuan726 "Title")
 ### 网页版本简历：[https://liuyuan726.github.io/liuyuanyuan.github.io/](https://liuyuan726.github.io/liuyuanyuan.github.io/ "resume")

 - 网页设计案例  [https://liuyuan726.github.io/liuyuanyuan.github.io/webpage1.html](https://liuyuan726.github.io/liuyuanyuan.github.io/webpage1.html "web")

 - 手机端案例    [https://liuyuan726.github.io/liuyuanyuan.github.io/mobile.html](https://liuyuan726.github.io/liuyuanyuan.github.io/mobile.html "mobile")

 - 平面案例    [https://liuyuan726.github.io/liuyuanyuan.github.io/plan.html](https://liuyuan726.github.io/liuyuanyuan.github.io/plan.html "plan")

 - 项目经验     [https://liuyuan726.github.io/liuyuanyuan.github.io/project.html](https://liuyuan726.github.io/liuyuanyuan.github.io/project.html "project")


